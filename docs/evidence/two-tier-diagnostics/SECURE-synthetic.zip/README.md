Click2Cloud diagnostics v2 · SECURE
Committed snapshot only. Multipart export: use every numbered part in order. Earlier/later unconfirmed observations are excluded. N/A means unavailable, not zero. No cloud probes or retries. A generated download is not proof of a physical disk write. ReDown import and Windows/live acceptance are separate.
