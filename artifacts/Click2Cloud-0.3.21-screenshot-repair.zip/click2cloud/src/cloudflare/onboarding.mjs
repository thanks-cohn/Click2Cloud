import {safeWorkerDiagnostic} from './deployment.mjs';
import {applyConfigChanges} from '../api/config.mjs';
const setupLocks=new WeakMap();
// initializeCloudflare/loginBegin: emptiness is durable, global and independent of OAuth/inventory.
const hasAssignments=s=>Object.values(s.configs).some(c=>(c.destinations??c.scopes??[]).length>0);
const hasSaved=s=>!!s.product.defaultTarget||hasAssignments(s);
const savedTargets=s=>[...new Map([s.product.defaultTarget,...Object.values(s.configs).flatMap(c=>(c.destinations??c.scopes??[]).map(d=>d.target))].filter(t=>t?.provider==='cloudflare').map(t=>[targetKey(t),t])).values()];
import {diagnoseCloudflare,hasWorkerWriteScope,hasWorkerCreateScope} from '../auth/cloudflare-oauth.mjs';
import {readBuckets} from './inventory.mjs';
import {fail,digest,remoteDestination} from './wire.mjs';
import {targetKey,scopeKey,normalizeTarget} from '../core/menu-identity.mjs';
export function createCloudflareOnboarding({current,oauth,provisioner,transport,inspectBucket,openShelf=async()=>{},readRequestedTarget=async()=>null,record=async()=>{},history=async()=>[]}){
 const setupApproved=async accountId=>{const a=await current.readSetupOperation?.('approval:'+accountId);return a?.accountId===accountId&&a.approved===true;};
 // recoverCloudflareDestination: a clicked Depth child is owned by its saved
 // scope, not by the current Default. Other modes retain exact target matching.
 function configuredScope(s,target){
  const depth=(s.configs.depth?.scopes??[]).map(x=>x.target).filter(t=>scopeKey(t)===scopeKey(target)&&target.prefix.startsWith(t.prefix)).sort((a,b)=>a.prefix.length-b.prefix.length)[0];
  return depth??savedTargets(s).find(t=>targetKey(t)===targetKey(target))??null;
 }
 async function destinationApproved(target){
  if(await setupApproved(target.accountId))return true;
  const a=await current.readSetupOperation?.('approval:destination:'+await digest([target.accountId,target.bucketName]));
  return a?.approved===true&&a.accountId===target.accountId&&a.bucketName===target.bucketName;
 }
 async function commit(mutator,key=crypto.randomUUID()){
  const s=await current.read(),next=structuredClone(s);mutator(next.product);
  await current.commitProduct({...next,expectedRevision:s.product.revision,idempotencyKey:'cloudflare:'+key,fingerprint:JSON.stringify(next.product)});
 }
 async function account(accountId){const a=await oauth.authority();if(!a.accounts.some(x=>x.id===accountId))fail('WRONG_ACCOUNT');return a;}
 async function r2(accountId){
  try{const a=await account(accountId),missing=['workers-r2.read'].filter(scope=>!a.scopes?.includes(scope));
   if(Array.isArray(a.scopes)&&missing.length)return {state:'INSUFFICIENT_PERMISSION',code:'INSUFFICIENT_SCOPE',accountId,diagnostic:{code:'INSUFFICIENT_SCOPE',evidence:'verified-grants',missingScopes:missing}};
   const result=await readBuckets(oauth,accountId);if(result.buckets)return {state:'ACTIVE',accountId,buckets:result.buckets};
   const diagnostic=diagnoseCloudflare(result.response,result.body,{context:'r2',scopes:a.scopes,requiredScopes:['workers-r2.read']}),code=diagnostic.code;
   return {state:code==='R2_CONFIRMED_INACTIVE'?'NOT_ACTIVATED':code==='INSUFFICIENT_SCOPE'?'INSUFFICIENT_PERMISSION':['TOKEN_EXPIRED','REAUTH_REQUIRED'].includes(code)?'RECONNECT_REQUIRED':code==='TRANSIENT_API_FAILURE'?'NETWORK_UNAVAILABLE':'UNKNOWN',code,accountId,diagnostic};
  }catch(e){const code=e.code??'TRANSIENT_API_FAILURE';return {state:['AUTH_REQUIRED','REAUTH_REQUIRED','TOKEN_EXPIRED','AUTH_SESSION_CHANGED'].includes(code)?'RECONNECT_REQUIRED':code==='WRONG_ACCOUNT'?'ACCOUNT_AMBIGUOUS':code==='INSUFFICIENT_SCOPE'?'INSUFFICIENT_PERMISSION':code==='TRANSIENT_API_FAILURE'?'NETWORK_UNAVAILABLE':'UNKNOWN',code,accountId,...(e.diagnostic?{diagnostic:e.diagnostic}:{})};}
 }
 const readyCache=new Map();
 async function check(accountId,selectedTarget,{force=true}={}){
  const statusStarted=performance.now(),s=await current.read();accountId??=selectedTarget?.accountId??s.product.defaultTarget?.accountId??s.product.cloudflare.selectedAccountId;let a;try{a=await oauth.authority();}catch(e){const code=e.code??'TRANSIENT_API_FAILURE';return {state:['AUTH_REQUIRED','REAUTH_REQUIRED','TOKEN_EXPIRED'].includes(code)?'RECONNECT_REQUIRED':code==='INSUFFICIENT_SCOPE'?'INSUFFICIENT_PERMISSION':code==='TRANSIENT_API_FAILURE'?'NETWORK_UNAVAILABLE':'UNKNOWN',code,...(e.diagnostic?{diagnostic:e.diagnostic}:{})};}if(!accountId&&!selectedTarget&&a.accounts.length===1)accountId=a.accounts[0].id;const key=JSON.stringify([a.sessionId,accountId,selectedTarget??s.product.defaultTarget]),cached=readyCache.get(key);if(!force&&cached&&Date.now()-cached.checkedAt<10000)return {...cached,fromCache:true,statusCheckMs:Math.round(performance.now()-statusStarted)};const result=await checkFresh(accountId,selectedTarget);if(result.state==='READY'){readyCache.set(key,{...result,checkedAt:Date.now()});if(readyCache.size>16)readyCache.delete(readyCache.keys().next().value);}return {...result,fromCache:false,statusCheckMs:Math.round(performance.now()-statusStarted)};
 }
 async function checkFresh(accountId,selectedTarget){
  const a=await oauth.status(),s=await current.read();accountId??=selectedTarget?.accountId??s.product.defaultTarget?.accountId??s.product.cloudflare.selectedAccountId;
  if(a.state!=='CONNECTED')return {state:'RECONNECT_REQUIRED'};
  if(!accountId||!a.accounts.some(x=>x.id===accountId))return {state:'ACCOUNT_AMBIGUOUS',...(accountId?{code:'WRONG_ACCOUNT'}:{}),accounts:a.accounts};
  const readiness=await r2(accountId);if(readiness.state!=='ACTIVE')return readiness;
  const choices=savedTargets(s).filter(t=>t.accountId===accountId),target=selectedTarget??s.product.defaultTarget??(choices.length===1?choices[0]:null);
  if(target){if(target.provider!=='cloudflare'||target.accountId!==accountId)return {state:'CHOOSE_DESTINATION',accountId};
   if(!readiness.buckets.some(b=>b.name===target.bucketName))return {state:'DESTINATION_UNAVAILABLE',accountId,target,code:'SELECTED_BUCKET_MISSING'};
   const worker=await transport.status(target);if(worker.state!=='READY'&&s.product.cloudflare.initialized.includes(accountId)&&!await setupApproved(accountId))return {state:'SETUP_APPROVAL_RECORD_MISSING',code:'SETUP_APPROVAL_RECORD_MISSING',accountId,target,worker};return {state:worker.state==='READY'?'READY':'REPAIR_REQUIRED',accountId,target,worker};
  }
  const state=hasSaved(s)?'CHOOSE_DESTINATION':await setupApproved(accountId)?'SETUP_RESUME_REQUIRED':s.product.cloudflare.initialized.includes(accountId)?'SETUP_APPROVAL_RECORD_MISSING':'SETUP_APPROVAL_REQUIRED';return {state,...(state==='SETUP_APPROVAL_RECORD_MISSING'?{code:state}:{}),accountId};
 }
 // Only explicit login/initialization invokes this path; status and boot stay read-only.
 let initializing;
 function initialize(options={}){return initializing??=(initializeLogin(options).finally(()=>{initializing=null;}));}
 async function initializeLogin(options){
  const auth=await oauth.authority(),s=await current.read();
  const configured=savedTargets(s),preferred=s.product.cloudflare.selectedAccountId??s.product.defaultTarget?.accountId;
  const accountId=preferred??(new Set(configured.map(t=>t.accountId)).size===1?configured[0]?.accountId:null)??(auth.accounts.length===1?auth.accounts[0].id:null);
  if(!accountId)return {state:'blocked',code:'ACCOUNT_AMBIGUOUS'};
  if(!auth.accounts.some(a=>a.id===accountId))return {state:'blocked',code:'WRONG_ACCOUNT'};
  return withSetupLock(accountId,()=>initializeAccount(accountId,options));
 }
 async function initializeAccount(accountId,{resume=false,authorizeSetup=false}={}){
  const auth=await account(accountId);const s=await current.read(),configured=savedTargets(s);
  if(s.product.defaultTarget&&(s.product.defaultTarget.provider!=='cloudflare'||s.product.defaultTarget.accountId!==accountId))return {state:'blocked',code:'DEFAULT_ACCOUNT_MISMATCH'};
  const targets=configured.filter(t=>t.accountId===accountId);
  // Link a legacy default-only target locally, without requiring cloud mutations.
  if(s.product.defaultTarget&&!hasAssignments(s)){const next=applyConfigChanges(s,[{type:'createDestination',mode:'simple',target:s.product.defaultTarget}]);await current.commitProduct({...next,expectedRevision:s.product.revision,idempotencyKey:'link-default:'+s.product.revision,fingerprint:targetKey(s.product.defaultTarget)});}
  const target=s.product.defaultTarget??(targets.length===1?targets[0]:null);
  if(!target&&hasSaved(s))return {state:'blocked',code:'CHOOSE_DESTINATION',accountId};
  const readiness=await check(accountId,target);
  if(readiness.state==='READY')return {state:'completed',code:'CLOUDFLARE_READY',target:readiness.target};
  if(!['SETUP_APPROVAL_REQUIRED','SETUP_RESUME_REQUIRED','SETUP_APPROVAL_RECORD_MISSING','REPAIR_REQUIRED','CHOOSE_DESTINATION'].includes(readiness.state))return {state:'blocked',code:readiness.code??readiness.state,stage:readiness.worker?'worker-readiness':'r2-readiness',accountId,...(readiness.diagnostic?{diagnostic:readiness.diagnostic}:{})};
  if(readiness.worker?.code==='WORKER_UPGRADE_APPROVAL_REQUIRED'&&!authorizeSetup)return {state:'blocked',code:readiness.worker.code,accountId,target,worker:readiness.worker};
  // Called only after the canonical Login's human consent and provisioning
  // authorization. Passive status/boot/refresh can never establish approval.
  if(authorizeSetup&&!await setupApproved(accountId)){
   await current.writeSetupOperation('approval:'+accountId,{accountId,approved:true});
  }
  if(!await setupApproved(accountId))return {state:'blocked',code:s.product.cloudflare.initialized.includes(accountId)?'SETUP_APPROVAL_RECORD_MISSING':'SETUP_APPROVAL_REQUIRED',accountId,target};
  const chosen=target??{provider:'cloudflare',connectionId:'cloudflare:'+accountId,accountId,bucketName:'redown',prefix:''};
  const pointer=await current.readSetupOperation?.('initialization:'+accountId),pending=pointer&&await current.readSetupOperation?.(accountId+':'+pointer.idempotencyKey);
  const failure=safeWorkerDiagnostic(pending?.failure);resume=resume||!!(failure&&auth.scopeEvidence==='provider-returned'&&auth.scopes?.includes('workers-scripts.admin')&&failure.sessionScopes.length>0&&!failure.sessionScopes.includes('workers-scripts.admin'));if(failure&&!resume)return {state:'blocked',code:failure.code,accountId,diagnostic:failure};
  const idempotencyKey=pending&&!pending.result&&targetKey(pending.target)===targetKey(chosen)?pointer.idempotencyKey:'v1:'+crypto.randomUUID();
  await current.writeSetupOperation?.('initialization:'+accountId,{idempotencyKey});
  return setupLocked({accountId,target,repair:!!target,automatic:true,resume,upgrade:authorizeSetup&&readiness.worker?.code==='WORKER_UPGRADE_APPROVAL_REQUIRED',expectedRevision:(await current.read()).product.revision,idempotencyKey});
 }
 function setup(params){return withSetupLock(params.accountId,()=>setupLocked(params));}
 function withSetupLock(accountId,run){
  const key='click2cloud-cloudflare-setup:'+accountId;
  if(globalThis.navigator?.locks?.request)return navigator.locks.request(key,run);
  const preceding=setupLocks.get(current)??Promise.resolve(),task=preceding.then(run,run);setupLocks.set(current,task.catch(()=>{}));return task;
 }
 async function setupLocked({accountId,expectedRevision,idempotencyKey,repair=false,target:repairTarget,automatic=false,resume=false,upgrade=false}){
  const started=performance.now(),auth=await account(accountId);let s=await current.read();
  const setupId=accountId+':'+idempotencyKey,prior=await current.readSetupOperation?.(setupId);
  if(prior?.result){if(prior.accountId!==accountId||repairTarget&&targetKey(prior.target)!==targetKey(repairTarget))fail('IDEMPOTENCY_CONFLICT');if(!savedTargets(s).some(t=>targetKey(t)===targetKey(prior.target)))return {state:'blocked',code:'SETUP_RESULT_STALE'};return prior.result;}
  if(s.product.revision!==expectedRevision)fail('REVISION_CONFLICT');
  if(s.product.cloudflare.initialized.includes(accountId)&&!await setupApproved(accountId))return {state:'blocked',code:'SETUP_APPROVAL_RECORD_MISSING',accountId};
  const selected=s.product.defaultTarget,configured=savedTargets(s).filter(t=>t.accountId===accountId);
  if(selected&&(selected.provider!=='cloudflare'||selected.accountId!==accountId))fail('WRONG_ACCOUNT');
  if(repairTarget&&(!repair||!configured.some(t=>targetKey(t)===targetKey(repairTarget))))fail('TARGET_NOT_CONFIGURED');
  const original=repairTarget??selected??(configured.length===1?configured[0]:null);
  if(!original&&hasSaved(s))return {state:'blocked',code:'CHOOSE_DESTINATION',accountId};
  const target=original??{provider:'cloudflare',connectionId:'cloudflare:'+accountId,accountId,bucketName:'redown',prefix:''},initial=!original;
  if(prior&&targetKey(prior.target)!==targetKey(target))fail('IDEMPOTENCY_CONFLICT');
  const status=await r2(accountId);if(status.state!=='ACTIVE')return {state:'blocked',code:status.code??status.state,diagnostic:status.diagnostic};
  if(!automatic&&!await setupApproved(accountId)){if(typeof current.writeSetupOperation!=='function')fail('SETUP_LEDGER_UNAVAILABLE');await current.writeSetupOperation('approval:'+accountId,{accountId,approved:true});}
  const missing=['workers-r2.write'].filter(scope=>!auth.scopes?.includes(scope));if(!hasWorkerWriteScope(auth.scopes))missing.push('workers-scripts.write');
  if(initial&&!status.buckets.some(b=>b.name===target.bucketName)&&!hasWorkerCreateScope(auth.scopes)){const diagnostic=safeWorkerDiagnostic({operation:'script-upload',workerIntent:'create',code:'WORKER_CREATE_PERMISSION_REQUIRED',classification:'OAUTH_SCOPE_MISSING',missingScopes:['workers-scripts.admin'],grantedScopes:auth.scopes,scopeEvidence:auth.scopeEvidence,selectedAccountVerified:true});return {state:'blocked',code:diagnostic.code,accountId,target,diagnostic};}
  if(!Array.isArray(auth.scopes)||missing.length)return {state:'blocked',code:'INSUFFICIENT_SCOPE',diagnostic:{code:'INSUFFICIENT_SCOPE',missingScopes:missing}};
  if(automatic&&!await setupApproved(accountId))return {state:'blocked',code:'SETUP_APPROVAL_REQUIRED',accountId};
  const exists=status.buckets.some(b=>b.name===target.bucketName);
  if(!exists&&!initial)return {state:'blocked',code:'DESTINATION_UNAVAILABLE'};
  if(!exists&&prior&&prior.stage!=='approved')return {state:'uncertain',code:'BUCKET_CREATE_UNCONFIRMED'};
  const active=await current.readSetupOperation?.('initialization:'+accountId),activeRecord=active&&await current.readSetupOperation?.(accountId+':'+active.idempotencyKey);
  if(!prior&&activeRecord&&!activeRecord.result&&targetKey(activeRecord.target)===targetKey(target)&&active.idempotencyKey!==idempotencyKey)return {state:'blocked',code:'SETUP_IN_PROGRESS',operationId:activeRecord.operationId};
  await current.writeSetupOperation?.('initialization:'+accountId,{idempotencyKey});
  let progressRecord=prior??{};
  const progress=async(stage,extra={})=>{progressRecord={...progressRecord,accountId,target,stage,...extra};await current.writeSetupOperation?.(setupId,progressRecord);};
  const stillSelected=async()=>{if((await oauth.authority()).sessionId!==auth.sessionId)fail('AUTHORIZATION_REVOKED');const now=await current.read();if(initial){if(hasSaved(now))fail('DESTINATIONS_CHANGED_DURING_SETUP');}else if(!savedTargets(now).some(t=>targetKey(t)===targetKey(target))||targetKey(now.product.defaultTarget??{})!==targetKey(selected??{}))fail('DESTINATIONS_CHANGED_DURING_SETUP');return now;};
  // Consent is persisted only by this explicitly approved API transition. Login
  // alone cannot add it; automatic callers must already have account approval.
  if(typeof current.writeSetupOperation!=='function'||typeof current.readSetupOperation!=='function')fail('SETUP_LEDGER_UNAVAILABLE');
  if(!automatic&&!await setupApproved(accountId))await current.writeSetupOperation('approval:'+accountId,{accountId,approved:true});
  const recovered=prior?.stage==='probe-dispatched'?await transport.probeStatus(target,prior.operationId):null;
  if(recovered&&recovered.state!=='verified')return {state:'uncertain',code:'SETUP_PROBE_REQUIRES_INSPECTION',operationId:prior.operationId};
  if(!prior)await progress('approved');
  await stillSelected();
  if(!exists){await progress('bucket-create-dispatched');try{const r=await oauth.request('/accounts/'+encodeURIComponent(accountId)+'/r2/buckets',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'redown'})});const creation=await r.json();if(!r.ok||creation.success!==true)throw Error('BUCKET_CREATE_UNCONFIRMED');}catch{const again=await r2(accountId);if(again.state!=='ACTIVE'||!again.buckets.some(b=>b.name==='redown'))return {state:'uncertain',code:'BUCKET_CREATE_UNCONFIRMED'};}}
  if(!recovered)await progress('bucket-confirmed');
  await stillSelected();const provisioningStarted=performance.now();
  if(!recovered)try{await provisioner.prepare(target,{approved:true,rebuild:upgrade||repair&&!automatic,retryDenied:resume||repair&&!automatic});}catch(error){const diagnostic=safeWorkerDiagnostic(error.diagnostic);if(!diagnostic)throw error;await progress('worker-preparation-blocked',{failure:diagnostic});return {state:'blocked',code:diagnostic.code,accountId,target,diagnostic};}const provisionMs=Math.round(performance.now()-provisioningStarted);
  if(!recovered){
   delete progressRecord.failure;await progress('worker-prepared');
   // workers.dev route propagation can briefly return non-JSON after a successful
   // upload. Retry only read-only capabilities, never a write/probe dispatch.
   let capability;
   for(let attempt=0;attempt<8;attempt++){
    await stillSelected();capability=await transport.status(target);
    if(['READY','PREPARED'].includes(capability.state))break;
    if(!['RESPONSE_INVALID','TRANSPORT_UNAVAILABLE','WORKER_BUILD_MISMATCH'].includes(capability.code)||attempt===7)return {state:'blocked',code:capability.code??'WORKER_NOT_READY',stage:'worker-capability',accountId,target};
    await new Promise(resolve=>setTimeout(resolve,Math.min(2000,250*2**attempt)));
   }
  }
  await stillSelected();
  const operationId=prior?.operationId??crypto.randomUUID();if(!recovered)await progress('probe-dispatched',{operationId});
  const probe=recovered??await transport.probe({target,operationId,authorize:async()=>{try{await stillSelected();return true;}catch{return false;}}});
  try{await record({...probe,kind:'readiness',timings:{...probe.timings,provisionMs}});if(probe.state!=='verified')return {state:probe.state==='uncertain'?'uncertain':'blocked',code:probe.code??'READINESS_WRITE_UNVERIFIED'};
   await stillSelected();await provisioner.markVerified(target,auth.sessionId);
   const latest=await stillSelected(),changes=[];
   if(initial){changes.push({type:'createDestination',mode:'simple',target,label:'redown'},{type:'makeDefault',target});}
   else if(selected&&!hasAssignments(latest))changes.push({type:'createDestination',mode:'simple',target:selected});
   const next=changes.length?applyConfigChanges(latest,changes):structuredClone(latest);
   if(initial)next.product.cloudflare.selectedAccountId=accountId;next.product.cloudflare.initialized=[...new Set([...next.product.cloudflare.initialized,accountId])];next.product.cloudflare.pending=next.product.cloudflare.pending.filter(x=>x!==accountId);
   await current.commitProduct({...next,expectedRevision:latest.product.revision,idempotencyKey:'setup-complete:'+setupId,fingerprint:JSON.stringify({target,changes})});
   readyCache.clear();const result={state:'completed',code:'CLOUDFLARE_READY',accountId,target,provisionMs,probe:probe.receipt,durationMs:Math.round(performance.now()-started)};await progress('complete',{operationId,result});return result;
  }catch(e){return {state:'uncertain',code:'SETUP_COMPLETION_PENDING',cause:/^[A-Z_]+$/.test(e.code??'')?e.code:'LOCAL_COMPLETION_UNCONFIRMED',operationId};}
 }
 // Owning API: recoverCloudflareDestination. This is the existing per-bucket
 // provisioner/probe transition, with an immutable selected target and its own
 // crash ledger. It never initializes redown, edits Default, or retains a URL.
 // A verified probe is resumed by operation ID; an uncertain probe is never
 // replayed. A completed ledger is not current readiness evidence.
 function recoverDestination(options){const target=normalizeTarget(options.target);remoteDestination(target);return withSetupLock(target.accountId,()=>recoverDestinationLocked({...options,target}));}
 async function recoverDestinationLocked({target,expectedRevision,idempotencyKey,authorizeSetup=false,screenshotUpgrade=false}){
  const accountId=target.accountId,auth=await account(accountId),s=await current.read();
  const blocked=(code,extra={})=>({state:'blocked',code,accountId,target,...extra});
  if(expectedRevision!==undefined&&s.product.revision!==expectedRevision)return blocked('REVISION_CONFLICT');
  if(!screenshotUpgrade&&!configuredScope(s,target))return blocked('TARGET_NOT_CONFIGURED');
  const plan=await provisioner.lookup?.(target);
  const screenshotScope=screenshotUpgrade&&plan?.accountId===accountId&&plan.bucketName===target.bucketName&&
    (!plan.prefixScope||target.prefix.startsWith(plan.prefixScope+'/'))?target:null;
  const selectedScope=state=>screenshotScope??configuredScope(state,target);
  const scope=selectedScope(s);
  if(!scope)return blocked('TARGET_NOT_CONFIGURED');
  if(screenshotUpgrade&&(!authorizeSetup||!screenshotScope))return blocked('SCREENSHOT_WORKER_UPDATE_REQUIRED');
  const bucketKey=await digest([accountId,target.bucketName]),approvalKey='approval:destination:'+bucketKey;
  const retainApproval=()=>current.writeSetupOperation?.(approvalKey,{accountId,bucketName:target.bucketName,approved:true});
  const expandScope=authorizeSetup&&!screenshotUpgrade&&!!plan?.prefixScope;
  const observed=await transport.status(target);
  const update=screenshotUpgrade&&!transport.screenshotWorkerCurrent(plan);
  const initialStatus=expandScope?{state:'blocked',code:'WORKER_DESTINATION_SCOPE_REQUIRED'}:
   update?{state:'blocked',code:'WORKER_UPGRADE_APPROVAL_REQUIRED'}:observed;
  if(initialStatus.state==='READY'){
   if(authorizeSetup&&!await destinationApproved(target))await retainApproval();
   return {state:'completed',code:'CLOUDFLARE_READY',accountId,target,readiness:initialStatus,reused:true};
  }
  if(initialStatus.code==='WORKER_DESTINATION_SCOPE_REQUIRED'&&!expandScope)return blocked(initialStatus.code,{requiredAction:'CONFIRM_SCOPE_CHANGE'});
  const requiresUpgrade=['WORKER_UPGRADE_APPROVAL_REQUIRED','WORKER_BUILD_MISMATCH'].includes(initialStatus.code);
  if(requiresUpgrade&&!authorizeSetup)return blocked(initialStatus.code,{requiredAction:'AUTHORIZE_WORKER_UPGRADE'});
  const requiresSigningRepair=['CAPABILITY_DENIED','WORKER_SIGNING_RENEWAL_APPROVAL_REQUIRED'].includes(observed.code);
  if(requiresSigningRepair&&!authorizeSetup)return blocked(initialStatus.code,{requiredAction:'AUTHORIZE_WORKER_REPAIR'});
  // Temporary inability to inspect a known Worker is not evidence it needs
  // redeployment. An exact readiness check is enough for the routine path.
  if(initialStatus.code&&!expandScope&&!requiresUpgrade&&!requiresSigningRepair&&!['WORKER_SETUP_REQUIRED','WRITE_PROOF_REQUIRED','WORKER_NOT_READY'].includes(initialStatus.code))return blocked(initialStatus.code);
  if(inspectBucket){
   if(await inspectBucket(target,auth)!==true)return blocked('AUTHORIZATION_DENIED');
  }else{
   const status=await r2(accountId);
   if(status.state!=='ACTIVE')return blocked(status.code??status.state,{diagnostic:status.diagnostic});
   if(!status.buckets.some(b=>b.name===target.bucketName))return blocked('SELECTED_BUCKET_MISSING');
  }
  if(typeof current.writeSetupOperation!=='function'||typeof current.readSetupOperation!=='function')return blocked('SETUP_LEDGER_UNAVAILABLE');
  if(!await destinationApproved(target)){
   if(!authorizeSetup)return blocked('SETUP_APPROVAL_REQUIRED',{requiredAction:'AUTHORIZE_EXACT_DESTINATION_SETUP'});
   await retainApproval();
  }
  const missing=['workers-r2.write'].filter(x=>!auth.scopes?.includes(x));if(!hasWorkerWriteScope(auth.scopes))missing.push('workers-scripts.write');
  if(!Array.isArray(auth.scopes)||missing.length)return blocked('INSUFFICIENT_SCOPE',{diagnostic:{code:'INSUFFICIENT_SCOPE',missingScopes:missing}});
  const pointerKey='destination-recovery:'+bucketKey;let pointer=await current.readSetupOperation(pointerKey);
  let existing=pointer&&await current.readSetupOperation(accountId+':'+pointer.idempotencyKey);
  async function reconcileOtherPrefixProbe(pending,pendingPointer){
   const probeTarget=normalizeTarget(pending.target),probeScope=configuredScope(s,probeTarget),operationId=pending.operationId;
   if(!probeScope||typeof operationId!=='string'||!operationId)return blocked('PROVISION_RECONCILE_REQUIRED',{setupTarget:probeTarget});
   if(pending.scopeTarget&&targetKey(pending.scopeTarget)!==targetKey(probeScope))return blocked('DESTINATIONS_CHANGED_DURING_SETUP',{setupTarget:probeTarget});
   const stillAuthorized=async()=>{
    if((await oauth.authority()).sessionId!==auth.sessionId)fail('AUTHORIZATION_REVOKED');
    const now=await current.read(),clickedScope=selectedScope(now),originalScope=configuredScope(now,probeTarget);
    if(!clickedScope||targetKey(clickedScope)!==targetKey(scope)||!originalScope||targetKey(originalScope)!==targetKey(probeScope)||!await destinationApproved(target)||!await destinationApproved(probeTarget))fail('DESTINATIONS_CHANGED_DURING_SETUP');
   };
   try{
    await stillAuthorized();const probe=await transport.probeStatus(probeTarget,operationId);await stillAuthorized();
    if(probe.state!=='verified')return {state:'uncertain',code:'SETUP_PROBE_REQUIRES_INSPECTION',accountId,target,probeTarget,operationId};
    await provisioner.markVerified(probeTarget,auth.sessionId);await stillAuthorized();
    const originalReadiness=await transport.status(probeTarget),readiness=await transport.status(target);await stillAuthorized();
    if(originalReadiness.state!=='READY'||readiness.state!=='READY')return blocked(readiness.code??originalReadiness.code??'WORKER_NOT_READY',{stage:'post-probe-readiness',probeTarget,operationId});
    const result={state:'completed',code:'CLOUDFLARE_READY',accountId,target,probeTarget,readiness,probe:probe.receipt,operationId,resumed:true};
    await current.writeSetupOperation(accountId+':'+pendingPointer.idempotencyKey,{...pending,stage:'complete',result:{...result,target:probeTarget,readiness:originalReadiness}});
    readyCache.clear();return result;
   }catch(error){return {state:'uncertain',code:'SETUP_COMPLETION_PENDING',cause:/^[A-Z_]+$/.test(error.code??'')?error.code:'PROBE_RECONCILIATION_UNCONFIRMED',accountId,target,probeTarget,operationId};}
  }
  async function resumeOtherPrefixSetup(pending,pendingPointer){
   const setupTarget=normalizeTarget(pending.target),setupScope=configuredScope(s,setupTarget);
   if(!setupScope||pending.scopeTarget&&targetKey(pending.scopeTarget)!==targetKey(setupScope))return blocked('DESTINATIONS_CHANGED_DURING_SETUP',{setupTarget});
   const resumed=await recoverDestinationLocked({target:setupTarget,expectedRevision:s.product.revision,idempotencyKey:pendingPointer.idempotencyKey});
   if(resumed.state!=='completed')return {...resumed,target,setupTarget};
   const now=await current.read(),clickedScope=selectedScope(now);
   if((await oauth.authority()).sessionId!==auth.sessionId||!clickedScope||targetKey(clickedScope)!==targetKey(scope)||!await destinationApproved(target))return blocked('DESTINATIONS_CHANGED_DURING_SETUP',{setupTarget});
   const readiness=await transport.status(target);
   if(readiness.state!=='READY')return blocked(readiness.code??'WORKER_NOT_READY',{stage:'post-probe-readiness',setupTarget});
   return {...resumed,target,probeTarget:setupTarget,readiness,resumed:true};
  }
  if(!pointer){
   const legacyPointer=await current.readSetupOperation('initialization:'+accountId),legacy=legacyPointer&&await current.readSetupOperation(accountId+':'+legacyPointer.idempotencyKey);
   if(legacy&&!legacy.result&&legacy.accountId===accountId&&legacy.target&&scopeKey(legacy.target)===scopeKey(target)){
    if(targetKey(legacy.target)===targetKey(target)){pointer=legacyPointer;existing=legacy;}
    else return legacy.stage==='probe-dispatched'?reconcileOtherPrefixProbe(legacy,legacyPointer):resumeOtherPrefixSetup(legacy,legacyPointer);
   }
  }
  if(existing&&(existing.accountId!==accountId||!existing.target||scopeKey(existing.target)!==scopeKey(target)))return blocked('PROVISION_RECONCILE_REQUIRED');
  // A sibling in this bucket may resume the same physical Worker, but a pending
  // probe remains bound to the original exact prefix until it is reconciled.
  const resumable=existing&&!existing.result;
  if(resumable&&targetKey(existing.target)!==targetKey(target))return existing.stage==='probe-dispatched'?reconcileOtherPrefixProbe(existing,pointer):resumeOtherPrefixSetup(existing,pointer);
  const key=resumable?pointer.idempotencyKey:idempotencyKey??'destination:'+crypto.randomUUID(),setupId=accountId+':'+key;
  let prior=await current.readSetupOperation(setupId);
  if(prior&&(prior.accountId!==accountId||!prior.target||targetKey(prior.target)!==targetKey(target)))return blocked('IDEMPOTENCY_CONFLICT');
  if(resumable&&pointer.idempotencyKey!==key)return blocked('SETUP_IN_PROGRESS',{operationId:existing.operationId});
  await current.writeSetupOperation(pointerKey,{idempotencyKey:key,accountId,bucketName:target.bucketName});
  let progressRecord=prior??{accountId,target,scopeTarget:scope};
  const progress=async(stage,extra={})=>{progressRecord={...progressRecord,stage,...extra};await current.writeSetupOperation(setupId,progressRecord);};
  const stillSelected=async()=>{
   if((await oauth.authority()).sessionId!==auth.sessionId)fail('AUTHORIZATION_REVOKED');
   const now=await current.read(),currentScope=selectedScope(now);if(!currentScope||targetKey(currentScope)!==targetKey(scope)||!await destinationApproved(target))fail('DESTINATIONS_CHANGED_DURING_SETUP');return true;
  };
  try{
   await stillSelected();
   let probe;
   if(prior?.stage==='probe-dispatched'){
    probe=await transport.probeStatus(target,prior.operationId);
    if(probe.state!=='verified')return {state:'uncertain',code:'SETUP_PROBE_REQUIRES_INSPECTION',accountId,target,operationId:prior.operationId};
   }else{
    if(!prior)await progress('approved');
    // Preserve a retained scope. A missing plan uses its configured scope;
    // neither a child click nor the Default can widen an existing plan.
    const currentPlan=await provisioner.lookup?.(target);
    const prepareOptions={approved:true,prefixScope:expandScope?'':currentPlan?.prefixScope??'',...(expandScope?{expandScope:true}:{}),
      inspect:true,rebuild:authorizeSetup&&requiresUpgrade,renewSigning:!screenshotUpgrade&&authorizeSetup&&requiresSigningRepair,retryDenied:true,...(screenshotUpgrade?{updateOnly:true}:{})};
    try{await provisioner.prepare(target,prepareOptions);}catch(error){
     // A pending plan can reveal its older build only during owned settings
     // inspection. Explicit repair approval covers that discovered upgrade;
     // an automatic recovery leaves it pending for informed authorization.
     if(!authorizeSetup||screenshotUpgrade&&error.code==='WORKER_SIGNING_RENEWAL_APPROVAL_REQUIRED'||!['WORKER_UPGRADE_APPROVAL_REQUIRED','WORKER_BUILD_MISMATCH','WORKER_SIGNING_RENEWAL_APPROVAL_REQUIRED'].includes(error.code))throw error;
     await provisioner.prepare(target,{...prepareOptions,rebuild:true,renewSigning:!screenshotUpgrade&&error.code==='WORKER_SIGNING_RENEWAL_APPROVAL_REQUIRED'});
    }
    await progress('worker-prepared');
    let capability;
    for(let attempt=0;attempt<8;attempt++){
     await stillSelected();capability=await transport.status(expandScope?{...target,prefix:''}:target);
     if(['READY','PREPARED'].includes(capability.state))break;
     if(!['RESPONSE_INVALID','TRANSPORT_UNAVAILABLE','WORKER_BUILD_MISMATCH'].includes(capability.code)||attempt===7)return blocked(capability.code??'WORKER_NOT_READY',{stage:'worker-capability'});
     await new Promise(resolve=>setTimeout(resolve,Math.min(2000,250*2**attempt)));
    }
    const operationId=prior?.operationId??crypto.randomUUID();await stillSelected();await progress('probe-dispatched',{operationId});
    probe=await transport.probe({target,operationId,authorize:async()=>{try{return await stillSelected();}catch{return false;}}});
    try{void Promise.resolve(record({...probe,kind:'readiness'})).catch(()=>{});}catch{}
    if(probe.state!=='verified')return {state:probe.state==='uncertain'?'uncertain':'blocked',code:probe.code??'READINESS_WRITE_UNVERIFIED',accountId,target,operationId};
   }
   await stillSelected();await provisioner.markVerified(target,auth.sessionId);
   const readiness=await transport.status(target);await stillSelected();
   if(readiness.state!=='READY')return blocked(readiness.code??'WORKER_NOT_READY',{stage:'post-probe-readiness'});
   readyCache.clear();
   const result={state:'completed',code:'CLOUDFLARE_READY',accountId,target,readiness,probe:probe.receipt,operationId:progressRecord.operationId};
   await progress('complete',{result});return result;
  }catch(error){
   const diagnostic=safeWorkerDiagnostic(error.diagnostic),code=diagnostic?.code??(/^[A-Z_]+$/.test(error.code??'')?error.code:'WORKER_RECOVERY_FAILED');
   if(progressRecord.stage==='probe-dispatched')return {state:'uncertain',code:'SETUP_COMPLETION_PENDING',cause:code,accountId,target,operationId:progressRecord.operationId};
   await progress('worker-preparation-blocked',{...(diagnostic?{failure:diagnostic}:{failureCode:code})});
   return blocked(code,{...(diagnostic?{diagnostic}:{}),...(code==='WORKER_DESTINATION_SCOPE_REQUIRED'?{requiredAction:'CONFIRM_SCOPE_CHANGE'}:['CAPABILITY_DENIED','WORKER_SIGNING_RENEWAL_APPROVAL_REQUIRED'].includes(code)?{requiredAction:'AUTHORIZE_WORKER_REPAIR'}:['WORKER_UPGRADE_APPROVAL_REQUIRED','WORKER_BUILD_MISMATCH'].includes(code)?{requiredAction:'AUTHORIZE_WORKER_UPGRADE'}:{})});
  }
 }
 // Explorer owns explicit file gestures. It neither reads the configured
 // Default nor needs a native menu. The source bucket is an additional binding
 // only for a transfer between buckets in the same OAuth account.
 async function ensureFileWorker(target,{sourceBucket,authorizeSetup=false,requireWriteProof=false,useSavedApproval=false}={}){
  return withSetupLock(target.accountId,async()=>{
   const auth=await account(target.accountId),plan=await provisioner.lookup(target,sourceBucket);
   const broad=plan?.state==='ready'&&!plan.prefixScope;
   if(broad&&(!requireWriteProof||!sourceBucket)){
    if(!requireWriteProof&&transport.filePlanCurrent(plan))return;
    if(requireWriteProof&&(await transport.status(target)).state==='READY')return;
   }
   if(!authorizeSetup&&!(useSavedApproval&&await destinationApproved(target)))fail('FILE_SETUP_APPROVAL_REQUIRED');
   if(inspectBucket&&await inspectBucket(target,auth)!==true)fail('AUTHORIZATION_DENIED');
   if(sourceBucket&&inspectBucket&&await inspectBucket({...target,bucketName:sourceBucket},auth)!==true)fail('AUTHORIZATION_DENIED');
   if(!hasWorkerWriteScope(auth.scopes))fail('INSUFFICIENT_SCOPE');
   if(!broad||!transport.filePlanCurrent(plan)){
    await provisioner.prepare(target,{sourceBucket,approved:true,expandScope:true,inspect:true,retryDenied:true,
     rebuild:!!plan&&!transport.filePlanCurrent(plan),renewSigning:!!plan&&!plan.secret});
   }
   let readiness;
   for(let attempt=0;attempt<5;attempt++){
    if((await account(target.accountId)).sessionId!==auth.sessionId)fail('AUTHORIZATION_REVOKED');
    readiness=await transport.status({...target,prefix:''},{sourceBucket});
    if(['PREPARED','READY'].includes(readiness.state))break;
    if(!['RESPONSE_INVALID','TRANSPORT_UNAVAILABLE','WORKER_BUILD_MISMATCH'].includes(readiness.code)||attempt===4)fail(readiness.code??'WORKER_NOT_READY');
    await new Promise(resolve=>setTimeout(resolve,250*2**attempt));
   }
   if(!requireWriteProof||readiness.state==='READY')return;
   const id='explorer-default:'+await digest(remoteDestination(target));
   let pending=await current.readSetupOperation(id);
   if(!pending){pending={operationId:crypto.randomUUID()};await current.writeSetupOperation(id,pending);
    readiness=await transport.probe({target,operationId:pending.operationId});
   }else readiness=await transport.probeStatus(target,pending.operationId);
   if(readiness.state!=='verified')fail(readiness.code??'READINESS_RECONCILE_REQUIRED');
   if((await account(target.accountId)).sessionId!==auth.sessionId)fail('AUTHORIZATION_REVOKED');
   await provisioner.markVerified(target,auth.sessionId);
   if((await transport.status(target)).state!=='READY')fail('WORKER_NOT_READY');
  });
 }
 async function invoke({provider,source,signal,authorize=async()=>true,requestedTarget,setupOnly=false,emptyAssignment=false,dispatchPreparationMs,attentionContext}){
  if(provider!=='cloudflare'){await openShelf(provider,undefined,{code:'PROVIDER_NOT_IMPLEMENTED',context:attentionContext});return {state:'blocked',code:'PROVIDER_NOT_IMPLEMENTED',provider};}
  const status=await oauth.status();
  if(status.state==='DISCONNECTED'){await openShelf('cloudflare',requestedTarget,{code:'LOGIN_REQUIRED',context:attentionContext});return {state:'blocked',code:'LOGIN_REQUIRED'};}
  if(status.state==='CONNECTING'){await openShelf('cloudflare',requestedTarget,{code:'LOGIN_IN_PROGRESS',context:attentionContext});return {state:'blocked',code:'LOGIN_IN_PROGRESS'};}
  if(emptyAssignment){const s=await current.read(),known=s.product.defaultTarget||s.product.cloudflare.initialized.length||s.product.cloudflare.removed?.length||Object.values(s.configs??{}).some(c=>(c.destinations??c.scopes??[]).some(d=>d.target.provider==='cloudflare'));if(known){await openShelf('manage-destinations',undefined,{code:'CHOOSE_DESTINATION',context:attentionContext});return {state:'blocked',code:'CHOOSE_DESTINATION'};}}
  const readiness=await check(requestedTarget?.accountId,requestedTarget,{force:false});
  if(readiness.state!=='READY'){if(readiness.state==='CHOOSE_DESTINATION')await openShelf('manage-destinations',undefined,{code:'CHOOSE_DESTINATION',context:attentionContext});else if(['SETUP_APPROVAL_REQUIRED','SETUP_RESUME_REQUIRED','SETUP_APPROVAL_RECORD_MISSING','REPAIR_REQUIRED','DESTINATION_UNAVAILABLE','ACCOUNT_AMBIGUOUS','NOT_ACTIVATED','RECONNECT_REQUIRED','INSUFFICIENT_PERMISSION','UNKNOWN','NETWORK_UNAVAILABLE'].includes(readiness.state))await openShelf('cloudflare',requestedTarget,{code:readiness.code??readiness.worker?.code??readiness.state,context:attentionContext});return {state:'blocked',code:readiness.code??readiness.worker?.code??readiness.state,requiredAction:readiness.state,accountId:readiness.accountId,target:requestedTarget};}
  if(setupOnly)return {state:'blocked',code:'FRESH_CLICK_REQUIRED',target:requestedTarget};
  if(!source?.url||source.bytes)return {state:'blocked',code:'REMOTE_SOURCE_REQUIRED'};
  const target=readiness.target,out=await transport.save({target,source,signal,dispatchPreparationMs,readinessMs:readiness.statusCheckMs,authorize:async()=>await authorize()&&savedTargets(await current.read()).some(t=>targetKey(t)===targetKey(target))});
  try{await record(out);}catch{return {...out,state:out.state==='verified'?'partial':out.state,code:'COMPLETION_PENDING'};}return out.state==='verified'?{...out,state:'completed',completion:'verified'}:out;
 }
 return Object.freeze({check,setup,initialize,recoverDestination,ensureFileWorker,invoke,history,async manage(){await openShelf('manage-destinations');return {state:'completed'};},cancel:({target,operationId})=>transport.cancel(target,operationId),setupStatus:({accountId,idempotencyKey})=>current.readSetupOperation?.(accountId+':'+idempotencyKey),
  async select(accountId){await account(accountId);if((await current.read()).product.cloudflare.selectedAccountId===accountId)return check(accountId);await commit(p=>{p.cloudflare.selectedAccountId=accountId;});return check(accountId);},
  async activation(accountId){await account(accountId);const result=await r2(accountId);return {state:'blocked',code:result.state==='ACTIVE'?'R2_ALREADY_ACTIVE':'R2_MANUAL_ACTION_REQUIRED',readiness:result};},
  async inspect(){const s=await current.read(),candidate=await readRequestedTarget(),valid=candidate&&configuredScope(s,candidate)?candidate:null;const status=candidate&&!valid?{state:'REPAIR_REQUIRED',code:'TARGET_NOT_CONFIGURED',accountId:candidate.accountId,target:candidate}:await check(valid?.accountId,valid),pointer=status.accountId&&await current.readSetupOperation?.(valid?'destination-recovery:'+await digest([valid.accountId,valid.bucketName]):'initialization:'+status.accountId),pending=pointer&&await current.readSetupOperation?.(status.accountId+':'+pointer.idempotencyKey),failure=!pending?.result&&safeWorkerDiagnostic(pending?.failure);return {onboarding:{...s.product.cloudflare,setupAuthorized:valid?await destinationApproved(valid):status.accountId?await setupApproved(status.accountId):false},status:failure?{...status,state:'PROVISIONING_BLOCKED',code:failure.code,diagnostic:failure}:status,limits:{totalFilePolicy:null,buffering:'bounded spool; final R2 conditional PUT service limits apply'},sourcePolicy:{kind:'public-https-native-fetch',privateNetworks:false,browserCredentials:false,networkGuarantee:'Public-address DNS preflight and per-hop HTTPS validation; native fetch re-resolves, so DNS rebinding is not fully pinned'}};},
  async receipt({operationId,target:explicitTarget}){
   const saved=await current.readRemoteResult?.(operationId)??(await history()).find(x=>x.operationId===operationId);const d=saved?.destination;
   const target=explicitTarget??(d?{provider:'cloudflare',connectionId:d.connectionId,accountId:d.accountId,bucketName:d.bucketName,prefix:d.prefix?d.prefix+'/':''}:null);
   if(!target)return {state:'blocked',code:'OPERATION_UNKNOWN'};
   const reconciliation=saved?.kind==='readiness'?await transport.inspect(target,saved.receipt):await transport.inspectOperation(target,operationId);
   if(reconciliation.state==='verified'&&saved?.state!=='verified'){const resolved={...saved,...reconciliation,operationId,destination:reconciliation.receipt?.destination??d};await record(resolved);return {...resolved,reconciliation};}
   return {...saved,reconciliation};
  }

 });
}
